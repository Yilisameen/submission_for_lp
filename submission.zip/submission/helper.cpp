#include <string_view>
#include <fstream>
#include <map>
#include <string>
#include <vector>
#include <memory>
#include "ctre.hpp"

using std::string_view;
using std::ifstream;
using std::ofstream;
using std::sort;
using std::unique_ptr;
using std::string;
using std::vector;
using std::map;


struct Operation {
    int time;
    int quatity;
    int price;
    
    Operation(int _time, int _quatity, int _price) {
        time = _time;
        quatity = _quatity;
        price = _price;
    };
};


bool mySymbolTimeSortFunc(unique_ptr<Operation> o1, unique_ptr<Operation> o2) {
    return o1->time < o2->time;
}

bool mySymbolPriceSortFunc(unique_ptr<Operation> o1, unique_ptr<Operation> o2) {
    return o1->price < o2->price;
}

struct SymbolRecord {
    string symbol;
    vector<unique_ptr<Operation>> allOpeations;
    
    int GetMaxTimeGap() {
        sort(allOpeations.begin(), allOpeations.end(), mySymbolSortFunc())
        return allOpeations.back()->time - allOpeations.front()->time;
    }
    
    int GetVolume() {
        int volume = 0;
        for(auto o : allOpeations) {
            volume += o->quatity * o->price;
        }
        return volume;
    }
    
    int GetWeighteAveragePrice() {
        int volume = 0;
        int total = 0;
        for(auto o : allOpeations) {
            volume += o->quatity * o->price;
            total += o->quatity;
        }
        return volume/total;
    }
    
    int GetMaxTradePrice() {
        sort(allOpeations.begin(), allOpeations.end(), mySymbolPriceSortFunc())
        return allOpeations.back()->price;
    }
};

void getAllOperations(istream& is, map<string, unique_ptr<SymbolRecord>>& allOperations) {
    static constexpr auto pattern = fixed_string{"(\\d+)\\s+(\\w+) \\s+(\\d+)\\s+(\\d+)"};
    string s;
    while(getline(is, s)) {
        auto [whole, ts, symbolName, q, p] = ctre::search<pattern>(string_view(s));
        if (whole) {
            int timestamp = stoi(string(ts));
            int quantity = stoi(string(q));
            int price = stoi(string(p));
            unique_ptr<Operation> uptr = std::make_unique<Operation>(timestamp, quantity, price);
            allOperations[string(symbolName)]->symbol = string(symbolName)
            allOperations[string(symbolName)]->allOpeations.push_back(move(uptr));
        }
        else{
            continue;
        }
    }
}

void file_handle(string_view const &input_file, string_view const &output_file){
    static constexpr auto filePattern = fixed_string{"\\w+\\.csv$"};
    if(ctre::match<filePattern>(input_file) && ctre::match<filePattern>(output_file)){
        ifstream ifs(input_file);
        ofstream ofs(output_file);
        formatFile(ifs, ofs);
    }
    else {
        std::cout << "Input file's format is not supported!" << std::endl;
    }
}

void formatFile(istream& ifs, ostream& ofs) {
    map<string, unique_ptr<SymbolRecord>> allRecords; //key: symbol, value: unique_ptr
    getAllOperations(ifs, allRecords);

    std::vector<int> keys;
    for (auto it = allRecords.begin(); it != allRecords.end(); it++) {
        keys.push_back(it->first);
    }
    std::sort(keys.begin(), keys.end());
        
    for (auto key : keys) {
        auto record = allRecords[key];
        ofs << key << " " << record->GetMaxTimeGap() << " " << record->GetVolume() << " " << record->GetWeighteAveragePrice() << " " << record->GetMaxTradePrice();
    }
}


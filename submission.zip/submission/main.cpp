#include <iostream>
#include <memory>
#include "helper.h"

using namespace std;

int main(int argc, const char * argv[]) {

    if (argc != 3)
    {
        cerr << "usage: " << argv[0] << " <input-file> <output-file>" << endl;
        return 1;
    }
    
    file_handle(argv[1], argv[2]);

    return 0;
}
